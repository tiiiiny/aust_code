# JSJDS-Data-themed-race

```
.
├── data                数据集
│   ├── investment
│   ├── world_health
│   └── zhwikisource
├── document            项目文档
│   └── resources
├── R-code              本项目的R代码
│   └── eda-doc
├── resources           与本项目无直接关系的资源
│   ├── from_paper
│   └── topic
├── results             数据分析结果
│   ├── results_IMR
│   └── results_invest
└── visualization       数据可视化
    ├── data
    ├── out
    └── raw_plot
```
