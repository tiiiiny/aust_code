
cp --archive ./* ../public/

rm --recursive ../public/resources
rm --recursive ../public/.idea
rm --recursive ../public/document/new_res

