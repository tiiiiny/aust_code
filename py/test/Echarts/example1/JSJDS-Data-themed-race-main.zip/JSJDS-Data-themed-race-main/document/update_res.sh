
cp --archive --force ./new_res/* ./resources/
cp --force ../results/IMR/pooled/pooled_average.pdf ./resources/IMR_pooled.pdf
cp --force ../results/5MR/pooled/pooled_average.pdf ./resources/5MR_pooled.pdf
cp --force "../results/IMR/黑山_ci_sc.pdf" ./resources/
